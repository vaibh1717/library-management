Please download WAMP(Windows)/XAMPP(Windows)/LAMP(Linux) if you want to host this project locally

Please Subscribe YouTube Channel
"Tech Vegan"

Channel Link: https://www.youtube.com/channel/UCs_dbtq_OF-0HxkAQnBGapA?sub_confirmation=1

For MoreProjects (Web & Hardware based)
Visit above Link

Default Admin Username & Password
Username: techvegan
Password: techvegan

Support
technologyvegan@gmail.com
https://www.ashishvegan.com